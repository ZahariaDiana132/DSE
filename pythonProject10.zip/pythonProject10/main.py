import os
import requests

MASTER_URL = 'http://192.168.0.170:5000'
AGENT1_URL = 'http://192.168.0.157:5000'
AGENT2_URL = 'http://192.168.0.160:5000'

def upload_file(file_path):
    with open(file_path, 'rb') as file:
        response = requests.post(f'{MASTER_URL}/upload', files={'file': file})
        print(response.json())

def list_files(agent_url):
    response = requests.get(f'{agent_url}/files')
    print(response.json())

def download_file(agent_url, filename):
    response = requests.get(f'{agent_url}/download/{filename}', stream=True)
    if response.status_code == 200:
        with open(f'downloads/{filename}', 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f'File {filename} downloaded successfully.')
    else:
        print(f'Failed to download file {filename}.')

if __name__ == '__main__':
    if not os.path.exists('downloads'):
        os.makedirs('downloads')

    # # Upload a file
    # file_path = r"C:\Users\diana\Desktop\newfile.txt"
    # upload_file(file_path)

    # List files on agent 1
    list_files(AGENT1_URL)

    # List files on agent 2
    list_files(AGENT2_URL)

    # Download a file from agent 1
    download_file(AGENT1_URL, 'newfile.txt')

    # # Download a file from agent 2
    # download_file(AGENT2_URL, 'newfile.txt')
