import os
import requests
from flask import Flask, render_template, request, redirect, url_for, send_file

app = Flask(__name__)

MASTER_URL = 'http://192.168.0.170:5000'
AGENT1_URL = 'http://192.168.0.157:5000'
AGENT2_URL = 'http://192.168.0.160:5000'

UPLOADS_FOLDER = 'uploads'
DOWNLOADS_FOLDER = os.path.join(os.path.expanduser('~'), 'Downloads')

if not os.path.exists(UPLOADS_FOLDER):
    os.makedirs(UPLOADS_FOLDER)

if not os.path.exists(DOWNLOADS_FOLDER):
    os.makedirs(DOWNLOADS_FOLDER)

def get_agent_files(agent_url):
    try:
        response = requests.get(f'{agent_url}/files')
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f'Error fetching files from agent at {agent_url}: {e}')
        return []

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' in request.files:
            file = request.files['file']
            if file.filename != '':
                file_path = os.path.join(UPLOADS_FOLDER, file.filename)
                file.save(file_path)
                response = requests.post(f'{MASTER_URL}/upload', files={'file': open(file_path, 'rb')})
                os.remove(file_path)
                if response.status_code == 200:
                    return redirect(url_for('index'))

    agent1_files = get_agent_files(AGENT1_URL)
    agent2_files = get_agent_files(AGENT2_URL)
    return render_template('index.html', agent1_files=agent1_files, agent2_files=agent2_files)

@app.route('/download/<agent>/<filename>', methods=['GET'])
def download_file(agent, filename):
    agent_url = AGENT1_URL if agent == 'agent1' else AGENT2_URL
    response = requests.get(f'{agent_url}/download/{filename}', stream=True)
    if response.status_code == 200:
        file_path = os.path.join(DOWNLOADS_FOLDER, filename)
        with open(file_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        return send_file(file_path, as_attachment=True)
    else:
        return 'Failed to download file.'

if __name__ == '__main__':
    app.run(debug=True)